package com.example.cp470_project.ui.statistics;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

import java.util.ArrayList;

public class StatisticsAdapter extends RecyclerView.Adapter<StatisticsViewHolder>{
    private Context context;
    private ArrayList<Stat> statistics;

    public StatisticsAdapter(Context ctx, ArrayList<Stat> stats){
        this.context = ctx;
        this.statistics = stats;
    }

    @NonNull
    @Override
    public StatisticsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.stats_bar,parent,false);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.height = (int) (parent.getHeight() / 6);
        return new StatisticsViewHolder((view));
    }

    @Override
    public void onBindViewHolder(@NonNull StatisticsViewHolder holder, int position) {
        Stat stat = statistics.get(position);
        holder.setName(stat.getName());
        holder.setProgress(stat.getProgress());
    }

    @Override
    public int getItemCount() {
        return statistics.size();
    }
}
