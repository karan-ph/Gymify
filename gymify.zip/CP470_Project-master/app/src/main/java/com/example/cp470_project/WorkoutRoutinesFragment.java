package com.example.cp470_project;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.cp470_project.ui.data.DatabaseHelper;
import com.example.cp470_project.ui.workout_logs.Constants;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WorkoutRoutinesFragment extends Fragment {
    private SQLiteDatabase db;
    private List<Routine> routines;
    private String[] workoutRoutineName;
    RoutineAdapter adapter;
    public WorkoutRoutinesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        DatabaseHelper databaseHelper = new DatabaseHelper(container.getContext());
        db = databaseHelper.getWritableDatabase();

        View view = inflater.inflate(R.layout.fragment_workout_routines, container, false);

        Button newRoutineButton = view.findViewById(R.id.newRoutineButton);
        ListView routineListView = view.findViewById(R.id.routineListView);


        try {
            routines = getRoutines();
            //workoutRoutineName = routines.keySet().toArray(new String[routines.size()]);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        adapter = new RoutineAdapter(requireContext(), routines);
        routineListView.setAdapter(adapter);

        newRoutineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createNewRoutine();
            }
        });

        return view;
    }

    private void createNewRoutine() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Create New Routine");


        // Set up the input fields in the dialog
        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText routineNameInput = new EditText(requireContext());
        routineNameInput.setHint("Enter routine name");
        layout.addView(routineNameInput);

        final EditText descriptionInput = new EditText(requireContext());
        descriptionInput.setHint("Enter routine description");
        layout.addView(descriptionInput);

        final EditText exercisesInput = new EditText(requireContext());
        exercisesInput.setHint("Enter Exercises (comma separated)");
        layout.addView(exercisesInput);

        builder.setView(layout);

        // Set up the buttons
        builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String routineName = routineNameInput.getText().toString();
                String routineDesc = descriptionInput.getText().toString();
                String exercises = exercisesInput.getText().toString();
                String[] exercisesArray = exercises.split(",");

                // Convert the array to an ArrayList
                ArrayList<String> exercisesList = new ArrayList<>(Arrays.asList(exercisesArray));
                Routine newRoutine = new Routine(routineName, routineDesc, exercisesList);
                insertNewRowRoutineData(newRoutine);
                Toast.makeText(requireContext(), "New routine created.", Toast.LENGTH_SHORT).show();

                adapter.addNewRoutine(newRoutine);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }
    public void insertNewRowRoutineData(Routine routine) {

        //JSONObject exerciseInfo = new JSONObject();
        int id = routine.getId();
        String name = routine.getName();
        String description = routine.getDescription();
        List<String> exercises = routine.getExercises();
        JSONArray exerciseArray = new JSONArray(exercises);

        ContentValues contentValues = new ContentValues();
        //contentValues.put(DatabaseHelper.KEY_WORKOUT_ROUTINES_ID, id);
        contentValues.put(DatabaseHelper.KEY_WORKOUT_ROUTINES_NAME, name);
        contentValues.put(DatabaseHelper.KEY_WORKOUT_ROUTINES_DESCRIPTION, description);
        contentValues.put(DatabaseHelper.KEY_WORKOUT_ROUTINES_EXERCISES, exerciseArray.toString());

        long routineID = db.insert(DatabaseHelper.TABLE_NAME_WORKOUT_ROUTINES, null, contentValues);
        routine.setId((int) routineID);
        //db.close();
    }
    private List<Routine> getRoutines() throws JSONException {
        List<Routine> routines = new ArrayList<Routine>();
        String sqlQuery = "SELECT * FROM " + DatabaseHelper.TABLE_NAME_WORKOUT_ROUTINES;
        Cursor cursor = db.rawQuery(sqlQuery, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_ID);
            int routinesID = cursor.getInt(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_NAME);
            String name = cursor.getString(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_DESCRIPTION);
            String description = cursor.getString(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_EXERCISES);
            JSONArray jsonArray = new JSONArray(cursor.getString(cursorIndex));
            List<String> exerciseNames = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                exerciseNames.add(jsonArray.getString(i));
            }
            Routine routine = new Routine(name, description, exerciseNames);
            routine.setId(routinesID);
            routines.add(routine);
            cursor.moveToNext();
        }
        cursor.close();
        return routines;
    }
}