package com.example.cp470_project;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {


    @Override
    protected void onCreate( Bundle savedInstanceState) {
        Log.i( "LoginActivity","calling function onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final Button button = findViewById(R.id.button2);
        final EditText email = findViewById(R.id.editTextTextPassword);
        SharedPreferences prefs = getSharedPreferences("DefaultEmail", Context.MODE_PRIVATE);
        String defaultEmail = prefs.getString("DefaultEmail","email@domain.com");
        email.setText(defaultEmail);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick (View view) {
                SharedPreferences prefs = getSharedPreferences("DefaultEmail", Context.MODE_PRIVATE);
                SharedPreferences.Editor ed = prefs.edit();
                ed.putString("DefaultEmail", email.getText().toString());

                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                ed.commit();
            }
        });



    }


    public void print(String s){
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
    public void onResume(){
        Log.i( "LoginActivity","calling function onResume");
        super.onResume();

    }

    public void onStart(){
        Log.i( "LoginActivity","calling function onStart");
        super.onStart();


    }
    public void onPause(){
        Log.i( "LoginActivity","calling function onPause");
        super.onPause();

    }

    public void onStop(){
        Log.i( "LoginActivity","calling function onStop");
        super.onStop();

    }

    public void onDestroy(){
        Log.i( "LoginActivity","calling function onDestroy");
        super.onDestroy();

    }
    public void onSaveInstanceState(Bundle dataStore){
        Log.i( "LoginActivity","calling function onSaveInstanceState");
        super.onSaveInstanceState(dataStore);

    }
    public void onRestoreInstanceState(Bundle savedInstanceState){
        Log.i( "LoginActivity","calling function onRestoreInstanceState");
        super.onRestoreInstanceState(savedInstanceState);

    }
}