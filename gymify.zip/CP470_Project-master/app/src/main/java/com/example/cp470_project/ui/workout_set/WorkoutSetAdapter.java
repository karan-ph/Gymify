package com.example.cp470_project.ui.workout_set;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;
import com.example.cp470_project.ui.workout_logs.WorkoutLog;
import com.example.cp470_project.ui.workout_logs.WorkoutLogsAdapter;

import java.util.List;

public class WorkoutSetAdapter extends RecyclerView.Adapter<WorkoutSetViewHolder> {
    List<WorkoutSet> workoutData;
    private OnClickListener onClickListener;
    private AfterTextChangedListener afterTextChangedListener;

    public WorkoutSetAdapter (List<WorkoutSet> workoutData) {
        this.workoutData = workoutData;
    }

    @NonNull
    @Override
    public WorkoutSetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.exercise_set, parent,false);
        return new WorkoutSetViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull WorkoutSetViewHolder holder, int position) {
        holder.setNumberTv.setText(String.format("Set %d", position + 1));
        holder.weightsEdit.setText(Double.toString(workoutData.get(position).getWeight()));
        holder.repsEdit.setText(Integer.toString(workoutData.get(position).getReps()));
        holder.deleteSetBtn.setOnClickListener(view -> {
            if (onClickListener != null) {
                onClickListener.onClick(holder.getAdapterPosition());
            }
        });
        holder.weightsEdit.setOnFocusChangeListener((view, b) -> {
            if (!b && afterTextChangedListener != null) {
                double newValue = Double.parseDouble(holder.weightsEdit.getText().toString());
                afterTextChangedListener.afterTextChanged(holder.getAdapterPosition(), newValue, "weights");
            }
        });
        holder.repsEdit.setOnFocusChangeListener((view, b) -> {
            if (!b && afterTextChangedListener != null) {
                double newValue = Double.parseDouble(holder.repsEdit.getText().toString());
                afterTextChangedListener.afterTextChanged(holder.getAdapterPosition(), newValue, "reps");
            }
        });
    }
    @Override
    public int getItemCount() {
        return workoutData.size();
    }
    public void setOnClickListener(WorkoutSetAdapter.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }
    public interface OnClickListener {
        void onClick(int position);
    }
    public void addAfterTextChangedListener(WorkoutSetAdapter.AfterTextChangedListener afterTextChangedListener) {
        this.afterTextChangedListener = afterTextChangedListener;
    }
    public interface AfterTextChangedListener {
        void afterTextChanged(int position, double value, String type);
    }
}
