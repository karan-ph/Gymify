package com.example.cp470_project.ui.workout_set;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

public class WorkoutSetViewHolder extends RecyclerView.ViewHolder {
    TextView setNumberTv;
    EditText repsEdit, weightsEdit;
    ImageView deleteSetBtn;
    public WorkoutSetViewHolder(@NonNull View itemView) {
        super(itemView);
        this.setNumberTv = itemView.findViewById(R.id.set_number_tv);
        this.repsEdit = itemView.findViewById(R.id.reps_edit);
        this.weightsEdit = itemView.findViewById(R.id.weight_edit);
        this.deleteSetBtn = itemView.findViewById(R.id.delete_set_btn);
    }
}
