package com.example.cp470_project.ui.statistics;
public class Stat {
    private String name;
    private int progress;

    public Stat (String name, int progress){
        this.name = name;
        this.progress = progress;
    }

    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }

    public int getProgress(){
        return this.progress;
    }

    public void setProgress(int progress){
        this.progress = progress;
    }
}
