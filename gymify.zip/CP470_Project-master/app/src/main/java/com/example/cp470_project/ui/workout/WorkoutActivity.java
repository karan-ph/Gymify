package com.example.cp470_project.ui.workout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.util.Log;

import com.example.cp470_project.R;
import com.example.cp470_project.ui.workout_logs.WorkoutLog;
import com.example.cp470_project.ui.workout_logs.WorkoutLogsFragment;

public class WorkoutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);
        WorkoutFragment workoutFragment = new WorkoutFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.workout_frame_layout, workoutFragment);
        fragmentTransaction.commit();
    }
}