package com.example.cp470_project.ui.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private final String TAG = "DatabaseHelper";
    public static final String DATABASE_NAME = "Gymify.db";
    private static final int VERSION_NUM = 1;
//    public static final String KEY_ID = "id";
//    public static final String KEY_USER_ID = "USER_ID";
//    public static final String KEY_CHEST = "IS_CHEST";
//    public static final String KEY_ARMS = "IS_ARMS";
//    public static final String KEY_BACK= "IS_BACK";
//    public static final String KEY_LEGS= "IS_LEGS";
//    public static final String KEY_NOTES = "NOTES";
//    public static final String TABLE_NAME = "MESSAGES";
//    private static final String DATABASE_CREATE = "create table "
//            + TABLE_NAME + " ( " + KEY_ID
//            + " integer primary key autoincrement, "
//            + KEY_USER_ID + " integer not null, "
//            + KEY_NOTES + " text not null, "
//            + KEY_CHEST + " BOOLEAN DEFAULT(FALSE), "
//            + KEY_ARMS + " BOOLEAN DEFAULT(FALSE), "
//            + KEY_BACK + " BOOLEAN DEFAULT(FALSE), "
//            + KEY_LEGS + " BOOLEAN DEFAULT(FALSE) );";
    public static final String TABLE_NAME_WORKOUT_LOG = "workout_log";
    public static final String KEY_WORKOUT_LOG_ID = "workout_log_id";
    public static final String KEY_WORKOUT_LOG_TITLE = "title";
    public static final String KEY_WORKOUT_LOG_DATE_CREATED = "date_created";
    public static final String KEY_WORKOUT_LOG_TIME_STARTED = "time_started";
    public static final String KEY_WORKOUT_LOG_TIME_ENDED = "time_ended";
    public static final String KEY_WORKOUT_LOG_ROUTINE_NAME = "routine_name";
    private static final String CREATE_TABLE_WORKOUT_LOG = "CREATE TABLE "
            + TABLE_NAME_WORKOUT_LOG + " ( "
            + KEY_WORKOUT_LOG_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + KEY_WORKOUT_LOG_TITLE + " TEXT NOT NULL, "
            + KEY_WORKOUT_LOG_DATE_CREATED + " TEXT NOT NULL, "
            + KEY_WORKOUT_LOG_TIME_STARTED + " TEXT NOT NULL, "
            + KEY_WORKOUT_LOG_TIME_ENDED + " TEXT NOT NULL, "
            + KEY_WORKOUT_LOG_ROUTINE_NAME + " TEXT NOT NULL);";
    public static final String TABLE_NAME_WORKOUT_DATA = "workout_data";
    public static final String KEY_WORKOUT_DATA_ID = "workout_data_id";
    public static final String KEY_WORKOUT_DATA_DATA = "data";
    public static final String KEY_WORKOUT_DATA_WORKOUT_LOG_ID = "workout_log_id";
    private static final String CREATE_TABLE_WORKOUT_DATA = "CREATE TABLE "
            + TABLE_NAME_WORKOUT_DATA + " ( "
            + KEY_WORKOUT_DATA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + KEY_WORKOUT_DATA_DATA + " TEXT NOT NULL, "
            + KEY_WORKOUT_DATA_WORKOUT_LOG_ID + " Integer NOT NULL);";
    public static final String TABLE_NAME_WORKOUT_ROUTINES = "workout_routines";
    public static final String KEY_WORKOUT_ROUTINES_ID = "workout_routines_id";
    public static final String KEY_WORKOUT_ROUTINES_NAME = "name";
    public static final String KEY_WORKOUT_ROUTINES_DESCRIPTION = "description";
    public static final String KEY_WORKOUT_ROUTINES_EXERCISES = "exercises";
    private static final String CREATE_TABLE_WORKOUT_ROUTINES = "CREATE TABLE "
            + TABLE_NAME_WORKOUT_ROUTINES + " ( "
            + KEY_WORKOUT_ROUTINES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + KEY_WORKOUT_ROUTINES_NAME + " TEXT NOT NULL, "
            + KEY_WORKOUT_ROUTINES_DESCRIPTION + " TEXT NOT NULL, "
            + KEY_WORKOUT_ROUTINES_EXERCISES + " TEXT NOT NULL);";
    private static final String DROP_TABLE_WORKOUT_LOG = "DROP TABLE IF EXISTS " + TABLE_NAME_WORKOUT_LOG;
    private static final String DROP_TABLE_WORKOUT_DATA = "DROP TABLE IF EXISTS " + TABLE_NAME_WORKOUT_DATA;
    private static final String DROP_TABLE_WORKOUT_ROUTINES = "DROP TABLE IF EXISTS " + TABLE_NAME_WORKOUT_ROUTINES;
    public DatabaseHelper(Context ctx) {
        super(ctx, DATABASE_NAME, null, VERSION_NUM);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_WORKOUT_LOG);
        db.execSQL(CREATE_TABLE_WORKOUT_DATA);
        db.execSQL(CREATE_TABLE_WORKOUT_ROUTINES);
        ContentValues contentValues1 = new ContentValues();
        contentValues1.put(KEY_WORKOUT_ROUTINES_NAME, "Chest");
        contentValues1.put(KEY_WORKOUT_ROUTINES_DESCRIPTION, "CHEST DAY");
        contentValues1.put(KEY_WORKOUT_ROUTINES_EXERCISES, "[\"Barbell Bench Press\",\"Dumbbell Shoulder Press\",\"Paused Barbell Bench Press\",\"Dips\"]");
        db.insert(TABLE_NAME_WORKOUT_ROUTINES, "NullPlaceHolder",contentValues1);
        ContentValues contentValues2 = new ContentValues();
        contentValues2.put(KEY_WORKOUT_ROUTINES_NAME, "Leg");
        contentValues2.put(KEY_WORKOUT_ROUTINES_DESCRIPTION, "LEG DAY");
        contentValues2.put(KEY_WORKOUT_ROUTINES_EXERCISES, "[\"Back Squat\",\"RDL\",\"Hack Squat\",\"Calf Raises\"]");
        db.insert(TABLE_NAME_WORKOUT_ROUTINES, "NullPlaceHolder",contentValues2);
        ContentValues contentValues3 = new ContentValues();
        contentValues3.put(KEY_WORKOUT_ROUTINES_NAME, "Pull");
        contentValues3.put(KEY_WORKOUT_ROUTINES_DESCRIPTION, "PULL DAY");
        contentValues3.put(KEY_WORKOUT_ROUTINES_EXERCISES, "[\"DeadLift\",\"Pull Ups\",\"Barbell Row\",\"Bicep Curls\"]");
        db.insert(TABLE_NAME_WORKOUT_ROUTINES, "NullPlaceHolder",contentValues3);
        Log.i(TAG, "Calling onCreate");
    }
    public void deleteRoutineById(int routineId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME_WORKOUT_ROUTINES, KEY_WORKOUT_ROUTINES_ID + " = ?",
                new String[]{String.valueOf(routineId)});
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL(DROP_TABLE_WORKOUT_LOG);
        db.execSQL(DROP_TABLE_WORKOUT_DATA);
        db.execSQL(DROP_TABLE_WORKOUT_ROUTINES);
        onCreate(db);
        Log.i(TAG, "Calling onUpgrade, oldVersion=" + i + " newVersion=" + i1);
    }
    @Override
    public void onDowngrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL(DROP_TABLE_WORKOUT_LOG);
        db.execSQL(DROP_TABLE_WORKOUT_DATA);
        onCreate(db);
        Log.i(TAG, "Calling onDowngrade, oldVersion=" + i + " newVersion=" + i1);
    }
}

