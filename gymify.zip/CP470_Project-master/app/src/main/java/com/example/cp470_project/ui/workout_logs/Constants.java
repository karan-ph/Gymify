package com.example.cp470_project.ui.workout_logs;

import com.example.cp470_project.Routine;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Constants {
    public static ArrayList<Routine> RoutineList= new ArrayList<>();
}
