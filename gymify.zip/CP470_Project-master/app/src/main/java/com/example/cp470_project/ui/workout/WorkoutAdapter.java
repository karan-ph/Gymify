package com.example.cp470_project.ui.workout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;
import com.example.cp470_project.ui.workout_set.WorkoutSet;
import com.example.cp470_project.ui.workout_set.WorkoutSetAdapter;

import java.util.List;
import java.util.Objects;

public class WorkoutAdapter extends RecyclerView.Adapter<WorkoutViewHolder> {
    private final String ADAPTER_NAME = "WorkoutAdapter";
    String[] exercises;
    List<List<WorkoutSet>> workoutHistory;
    private OnClickListener onClickListener;
    private OnUpdateListener onUpdateListener;
    private final RecyclerView.RecycledViewPool viewPool = new RecyclerView.RecycledViewPool();
    public WorkoutAdapter (String[] exercises, List<List<WorkoutSet>> workoutHistory) {
        this.exercises = exercises;
        this.workoutHistory = workoutHistory;
    }
    @NonNull
    @Override
    public WorkoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.exercise, parent,false);
        return new WorkoutViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull WorkoutViewHolder holder, int position) {
        holder.exerciseTitleTv.setText(exercises[position]);
        holder.addSetBtn.setOnClickListener(view -> {
            if (onClickListener != null) {
                onClickListener.onClick(holder.getAdapterPosition(), workoutHistory.get(holder.getAdapterPosition()));
            }
        });
        LinearLayoutManager layoutManager = new LinearLayoutManager(holder.exerciseSetRecyclerView.getContext(), LinearLayoutManager.VERTICAL, false);
        WorkoutSetAdapter workoutSetAdapter = new WorkoutSetAdapter(workoutHistory.get(position));
        holder.exerciseSetRecyclerView.setLayoutManager(layoutManager);
        holder.exerciseSetRecyclerView.setAdapter(workoutSetAdapter);
        holder.exerciseSetRecyclerView.setRecycledViewPool(viewPool);

        workoutSetAdapter.setOnClickListener((childPosition) -> {
            workoutHistory.get(position).remove(childPosition);
            if (onUpdateListener != null) {
                onUpdateListener.onUpdate();
            }
            this.notifyItemChanged(position);
        });
        workoutSetAdapter.addAfterTextChangedListener((childPosition, value, type) -> {
            if (Objects.equals(type, "weights")) {
                if (workoutHistory.get(position).get(childPosition).getWeight() != value){
                    workoutHistory.get(position).get(childPosition).setWeight(value);
                }
            } else if (Objects.equals(type, "reps")) {
                if (workoutHistory.get(position).get(childPosition).getReps() != (int) value){
                    workoutHistory.get(position).get(childPosition).setReps((int) value);
                }
            }
            if (onUpdateListener != null) {
                onUpdateListener.onUpdate();
            }
//            if (!holder.exerciseSetRecyclerView.isComputingLayout()){
//                this.notifyItemChanged(position);
//            }
            Log.i(ADAPTER_NAME, "workout history: " + workoutHistory.get(position).get(childPosition).getWeight());
        });
    }
    @Override
    public int getItemCount() {
        return workoutHistory.size();
    }
    public interface OnClickListener {
        void onClick(int position, List<WorkoutSet> workoutSetData);
    }
    public void setOnClickListener(WorkoutAdapter.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }
    public interface OnUpdateListener {
        void onUpdate();
    }
    public void setOnUpdateListener(OnUpdateListener onUpdateListener) {
        this.onUpdateListener = onUpdateListener;
    }
}
