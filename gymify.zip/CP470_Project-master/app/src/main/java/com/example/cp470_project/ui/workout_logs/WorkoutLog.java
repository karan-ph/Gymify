package com.example.cp470_project.ui.workout_logs;

import com.example.cp470_project.Routine;

import java.io.Serializable;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;

public class WorkoutLog implements Serializable {
    String title;
    String timeDuration;
    int day_num;
    Month month;
    DayOfWeek day_name;
    int year;
    LocalTime timeStarted;
    LocalTime timeEnded;
    LocalDate dateCreated;
    int workoutID;
    String routineTitle;

    public WorkoutLog(String title, LocalDate dateCreated, LocalTime timeStarted, LocalTime timeEnded, String routineTitle) {
        this.title = title;
        if (timeEnded == LocalTime.parse("00:00")) {
            this.timeDuration = "No End Time";
        } else if (timeStarted == LocalTime.parse("00:00")) {
            this.timeDuration = "No Start Time";
        } else {
            this.timeDuration = String.format("%d mins", Duration.between(timeStarted, timeEnded).toMinutes());
        }
        this.day_name = dateCreated.getDayOfWeek();
        this.day_num = dateCreated.getDayOfMonth();
        this.month = dateCreated.getMonth();
        this.year = dateCreated.getYear();
        this.timeStarted = timeStarted;
        this.timeEnded = timeEnded;
        this.dateCreated = dateCreated;
        this.routineTitle = routineTitle;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTimeDuration() {
        return timeDuration;
    }

    public void setTimeDuration() {
        if (timeEnded == LocalTime.parse("00:00")) {
            this.timeDuration = "No End Time";
        } else if (timeStarted == LocalTime.parse("00:00")) {
            this.timeDuration = "No Start Time";
        } else {
            this.timeDuration = String.format("%d mins", Duration.between(timeStarted, timeEnded).toMinutes());
        }
    }

    public String getDayName() {
        return day_name.toString();
    }

    public void setDayName() {
        this.day_name = dateCreated.getDayOfWeek();
    }

    public String getDayNum() {
        return Integer.toString(day_num);
    }

    public void setDayNum() {
        this.day_num = dateCreated.getDayOfMonth();
    }

    public String getMonth() {
        return month.toString();
    }

    public void setMonth() {
        this.month = dateCreated.getMonth();
    }

    public int getYear() {
        return year;
    }

    public void setYear() {
        this.year = dateCreated.getYear();
    }

    public LocalTime getTimeStarted() {
        return timeStarted;
    }

    public void setTimeStarted(LocalTime timeStarted) {
        this.timeStarted = timeStarted;
    }

    public LocalTime getTimeEnded() {
        return timeEnded;
    }

    public void setTimeEnded(LocalTime timeEnded) {
        this.timeEnded = timeEnded;
    }
    public LocalDate getDateCreated() {
        return this.dateCreated;
    }
    public void setDateCreated(LocalDate dateCreated) {
        this.dateCreated = dateCreated;
    }

    public void setWorkoutID(int workoutID) {
        this.workoutID = workoutID;
    }

    public int getWorkoutID() {
        return workoutID;
    }
    public String getRoutineTitle() {
        return routineTitle;
    }
    public void setRoutineTitle(String routineTitle) {
        this.routineTitle = routineTitle;
    }
}
