package com.example.cp470_project.ui.workout;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.cp470_project.databinding.FragmentWorkoutBinding;
import com.example.cp470_project.ui.data.DatabaseHelper;
import com.example.cp470_project.ui.workout_logs.WorkoutLog;
import com.example.cp470_project.ui.workout_logs.WorkoutLogsFragment;
import com.example.cp470_project.ui.workout_set.WorkoutSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class WorkoutFragment extends Fragment {
    private final static String FRAGMENT_NAME = "WorkoutFragment";
    private FragmentWorkoutBinding binding;
    private String workoutTitle;
    private LocalDate workoutDateCreated;
    private LocalTime workoutTimeStarted;
    private LocalTime workoutTimeEnded;
    private int workoutLogID;
    private int position;
    WorkoutLog workoutLog;
    List<List<WorkoutSet>> workoutHistory;
    String[] exerciseNames;
    private SQLiteDatabase db;
    private int workoutSessionID;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentWorkoutBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Intent intent = getActivity().getIntent();
        workoutLog = (WorkoutLog) intent.getSerializableExtra(WorkoutLogsFragment.ARG_OBJECT_NAME);
        workoutTitle = workoutLog.getTitle();
        workoutDateCreated = workoutLog.getDateCreated();
        workoutTimeStarted = workoutLog.getTimeStarted();
        workoutTimeEnded = workoutLog.getTimeEnded();
        workoutLogID = workoutLog.getWorkoutID();
        position = intent.getIntExtra(WorkoutLogsFragment.ARG_POSITION, -1);
        exerciseNames = intent.getStringArrayExtra(WorkoutLogsFragment.ARG_EXERCISES);
        boolean isNewSession = intent.getBooleanExtra(WorkoutLogsFragment.ARG_IS_NEW_SESSION, false);

        DatabaseHelper databaseHelper = new DatabaseHelper(getContext());
        db = databaseHelper.getWritableDatabase();

//        Log.i(FRAGMENT_NAME, "exercises: " + Arrays.toString(exerciseNames));
//        Log.i(FRAGMENT_NAME, "new session? " + isNewSession);

        try {
            workoutHistory = readWorkoutData();
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        binding.workoutRecyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        WorkoutAdapter workoutAdapter = new WorkoutAdapter(exerciseNames, workoutHistory);
        binding.workoutRecyclerview.setAdapter(workoutAdapter);

        binding.workoutTitleEdit.setText(workoutTitle);
        binding.workoutDatePicker.setText(workoutDateCreated.toString());
        binding.workoutTimeStartedEdit.setText(workoutTimeStarted.toString());
        binding.workoutTimeEndedEdit.setText(workoutTimeEnded.toString());

        binding.workoutDatePicker.setOnClickListener(view -> {
            int year = workoutDateCreated.getYear();
            int month = workoutDateCreated.getMonthValue() - 1;
            int day = workoutDateCreated.getDayOfMonth();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    getActivity(),
                    (view1, new_year, new_month, new_day) -> {
                        Log.i(FRAGMENT_NAME, new_year + "-" + (new_month + 1) + "-" + new_day);
                        workoutDateCreated = LocalDate.parse(String.format("%d-%02d-%02d", new_year, (new_month + 1), new_day));
                        binding.workoutDatePicker.setText(workoutDateCreated.toString());
                        workoutLog.setDateCreated(workoutDateCreated);
                        workoutLog.setDayName();
                        workoutLog.setDayNum();
                        workoutLog.setMonth();
                        workoutLog.setYear();
                        sendResults();
                    }, year, month, day);
            datePickerDialog.show();
        });
        binding.workoutTimeStartedEdit.setOnClickListener(view -> {
            int hour = workoutTimeStarted.getHour();
            int minute = workoutTimeStarted.getMinute();

            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    getActivity(),
                    (view1, new_hour, new_minute) -> {
                        workoutTimeStarted = LocalTime.parse(String.format("%02d:%02d", new_hour, new_minute), DateTimeFormatter.ofPattern("HH:mm"));
                        binding.workoutTimeStartedEdit.setText(workoutTimeStarted.toString());
                        workoutLog.setTimeStarted(workoutTimeStarted);
                        workoutLog.setTimeDuration();
                        sendResults();
                    }, hour, minute, true);
            timePickerDialog.show();
        });
        binding.workoutTimeEndedEdit.setOnClickListener(view -> {
            int hour = workoutTimeEnded.getHour();
            int minute = workoutTimeEnded.getMinute();

            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    getActivity(),
                    (view1, new_hour, new_minute) -> {
                        workoutTimeEnded = LocalTime.parse(String.format("%02d:%02d", new_hour, new_minute), DateTimeFormatter.ofPattern("HH:mm"));
                        binding.workoutTimeEndedEdit.setText(workoutTimeEnded.toString());
                        workoutLog.setTimeEnded(workoutTimeEnded);
                        workoutLog.setTimeDuration();
                        sendResults();
                    }, hour, minute, true);
            timePickerDialog.show();
        });
        binding.workoutTitleEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!editable.toString().equals(workoutTitle)) {
                    workoutLog.setTitle(binding.workoutTitleEdit.getText().toString());
                    sendResults();
                }
            }
        });
        workoutAdapter.setOnClickListener((position, workoutSetHistory) -> {
            workoutSetHistory.add(new WorkoutSet(0, 0));
            workoutHistory.set(position, workoutSetHistory);
//            Log.i(FRAGMENT_NAME, "data: " + workoutHistory.get(position).toString());
            updateWorkoutData();
            binding.workoutRecyclerview.getAdapter().notifyItemChanged(position);
        });
        workoutAdapter.setOnUpdateListener(this::updateWorkoutData);

        return root;
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    private void sendResults(){
        Intent returnIntent = new Intent();
        returnIntent.putExtra(WorkoutLogsFragment.ARG_OBJECT_NAME, workoutLog);
        returnIntent.putExtra(WorkoutLogsFragment.ARG_POSITION, position);
        getActivity().setResult(WorkoutLogsFragment.CODE_RESULT, returnIntent);
    }
    public void updateWorkoutData() {
        JSONObject workoutSession = new JSONObject();
        for (int i = 0; i < workoutHistory.size(); i++) {
            JSONArray exercise = new JSONArray();
            for (int j = 0; j < workoutHistory.get(i).size(); j++) {
                JSONArray workoutSet = new JSONArray();
                try {
                    workoutSet.put(workoutHistory.get(i).get(j).getWeight());
                    workoutSet.put(workoutHistory.get(i).get(j).getReps());
                    exercise.put(workoutSet);
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
            try {
                workoutSession.put(exerciseNames[i], exercise);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        Log.i(FRAGMENT_NAME, "json: " + workoutSession);
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_WORKOUT_DATA_DATA, workoutSession.toString());
        db.update(DatabaseHelper.TABLE_NAME_WORKOUT_DATA, contentValues, DatabaseHelper.KEY_WORKOUT_DATA_ID + "=?",new String[]{String.valueOf(workoutSessionID)});
    }
    private List<List<WorkoutSet>> readWorkoutData() throws JSONException {
        String sqlQuery = "SELECT * FROM "
                + DatabaseHelper.TABLE_NAME_WORKOUT_DATA
                + " WHERE " + DatabaseHelper.KEY_WORKOUT_DATA_WORKOUT_LOG_ID
                + " = " + workoutLogID;
        Cursor cursor = db.rawQuery(sqlQuery, null);
        List<List<WorkoutSet>> workoutData = new ArrayList<>();
        cursor.moveToFirst();
        int cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_DATA_ID);
        workoutSessionID = cursor.getInt(cursorIndex);
        cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_DATA_DATA);
        String data = cursor.getString(cursorIndex);

        cursor.close();

        JSONObject workoutSession = new JSONObject(data);
        for (Iterator<String> it = workoutSession.keys(); it.hasNext(); ) {
            String exerciseName = it.next();
            List<WorkoutSet> exercises = new ArrayList<>();
            JSONArray exercise = workoutSession.getJSONArray(exerciseName);
            for (int i = 0; i < exercise.length(); i++) {
                JSONArray workoutSet = exercise.getJSONArray(i);
                double weight = (int) workoutSet.get(0);
                int reps = (int) workoutSet.get(1);
                exercises.add(new WorkoutSet(weight, reps));
            }
            workoutData.add(exercises);
        }
        return workoutData;
    }
}