package com.example.cp470_project.ui.workout_logs;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

public class WorkoutLogsViewHolder extends RecyclerView.ViewHolder {

    TextView titleTV, timeDurationTV, dayTV, dateNumTV, monthTV;
    public WorkoutLogsViewHolder(@NonNull View itemView) {
        super(itemView);
        this.titleTV = itemView.findViewById(R.id.workout_log_title);
        this.timeDurationTV = itemView.findViewById(R.id.workout_log_time_duration);
        this.dayTV = itemView.findViewById(R.id.workout_log_day_created);
        this.dateNumTV = itemView.findViewById(R.id.workout_log_date_no_created);
        this.monthTV = itemView.findViewById(R.id.workout_log_date_month_created);
    }
}
