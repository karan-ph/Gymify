package com.example.cp470_project.ui.workout_logs;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

import java.util.ArrayList;
import java.util.List;

public class WorkoutLogsAdapter extends RecyclerView.Adapter<WorkoutLogsViewHolder> {
    private final static String ACTIVITY_NAME = "WorkoutLogsAdapter";
    private final static String ARG_WORKOUT_TITLE = "workout_title";
    private final List<WorkoutLog> workoutLogs;
    private OnClickListener onClickListener;

    public WorkoutLogsAdapter(List<WorkoutLog> workoutLogs) {
        this.workoutLogs = workoutLogs;
    }
    @NonNull
    @Override
    public WorkoutLogsViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.workout_log_item_views,parent, false);
        return new WorkoutLogsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkoutLogsViewHolder holder, int position) {
        holder.titleTV.setText(workoutLogs.get(position).getTitle());
        holder.timeDurationTV.setText(workoutLogs.get(position).getTimeDuration());
        holder.dayTV.setText(workoutLogs.get(position).getDayName());
        holder.monthTV.setText(workoutLogs.get(position).getMonth());
        holder.dateNumTV.setText(workoutLogs.get(position).getDayNum());
        holder.itemView.setClickable(true);
        holder.itemView.setOnClickListener(view -> {
            if (onClickListener != null) {
                onClickListener.onClick(holder.getAdapterPosition(), workoutLogs.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return workoutLogs.size();
    }
    public void setOnClickListener(OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }
    public interface OnClickListener {
        void onClick(int position, WorkoutLog workoutLog);
    }
}
